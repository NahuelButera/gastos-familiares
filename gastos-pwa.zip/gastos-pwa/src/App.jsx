import { useState, useEffect, useRef, useCallback } from "react";

// ── JSONBin config ──
const JSONBIN_API_KEY = "$2a$10$0rAxxRZaKB/XebBCh6AETO0d4wSBuvi9bNZE.wtL/ovcOYQ9wIMdK";
const JSONBIN_BASE = "https://api.jsonbin.io/v3";
const BIN_ID_KEY = "gf_bin_id";

// ── Constants ──
const CATEGORIES = [
  { id: "mercaderia", label: "Mercadería", icon: "🛒", color: "#2D7D6F" },
  { id: "servicios",  label: "Servicios",  icon: "⚡", color: "#4A7FA5" },
  { id: "transporte", label: "Transporte", icon: "🚗", color: "#7B6FA5" },
  { id: "salud",      label: "Salud",      icon: "🏥", color: "#A56F6F" },
  { id: "ocio",       label: "Ocio",       icon: "🎬", color: "#A58B6F" },
  { id: "ropa",       label: "Ropa",       icon: "👕", color: "#6FA58B" },
  { id: "otro",       label: "Otro",       icon: "📦", color: "#8B8B8B" },
];
const USERS = [
  { id: "N", name: "Nahuel",    avatar: "N", color: "#2D7D6F" },
  { id: "F", name: "Florencia", avatar: "F", color: "#A56F8F" },
];
const fmt = (n) => new Intl.NumberFormat("es-AR", { style: "currency", currency: "ARS", maximumFractionDigits: 0 }).format(n || 0);
const todayStr = () => new Date().toISOString().split("T")[0];
const startOfWeekStr = () => { const d = new Date(); d.setDate(d.getDate() - d.getDay()); return d.toISOString().split("T")[0]; };
const getCat = (id) => CATEGORIES.find(c => c.id === id) || CATEGORIES[6];
const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 6);

const EMPTY_STATE = { expenses: [], incomes: [], shopping: [] };

// ── JSONBin API ──
async function createBin(data) {
  const res = await fetch(`${JSONBIN_BASE}/b`, {
    method: "POST",
    headers: { "Content-Type": "application/json", "X-Master-Key": JSONBIN_API_KEY, "X-Bin-Name": "gastos-familiares", "X-Bin-Private": "false" },
    body: JSON.stringify(data),
  });
  const json = await res.json();
  return json.metadata?.id;
}

async function readBin(binId) {
  const res = await fetch(`${JSONBIN_BASE}/b/${binId}/latest`, {
    headers: { "X-Master-Key": JSONBIN_API_KEY },
  });
  const json = await res.json();
  return json.record;
}

async function writeBin(binId, data) {
  await fetch(`${JSONBIN_BASE}/b/${binId}`, {
    method: "PUT",
    headers: { "Content-Type": "application/json", "X-Master-Key": JSONBIN_API_KEY },
    body: JSON.stringify(data),
  });
}

// ── User picker ──
function UserPicker({ onPick }) {
  return (
    <div style={{ ...S.screen, padding: "0 24px", justifyContent: "center", alignItems: "center" }}>
      <div style={{ textAlign: "center", marginBottom: 40 }}>
        <div style={{ fontSize: 40, marginBottom: 10 }}>👋</div>
        <div style={{ fontSize: 22, fontWeight: 700, color: "#1A1A1A" }}>¿Quién sos?</div>
        <div style={{ fontSize: 14, color: "#888", marginTop: 8 }}>Esto queda guardado en tu celular</div>
      </div>
      <div style={{ display: "flex", flexDirection: "column", gap: 14, width: "100%" }}>
        {USERS.map(u => (
          <button key={u.id} style={{ ...S.btnPrimary, background: u.color, justifyContent: "center", fontSize: 18, padding: "20px" }}
            onClick={() => { localStorage.setItem("gf_user", u.id); onPick(u.id); }}>
            <span style={{ fontSize: 28, fontWeight: 700, marginRight: 8 }}>{u.avatar}</span> {u.name}
          </button>
        ))}
      </div>
    </div>
  );
}

// ── Main App ──
export default function App() {
  const [activeUser, setActiveUser] = useState(() => localStorage.getItem("gf_user") || null);
  const [binId, setBinId]           = useState(() => localStorage.getItem(BIN_ID_KEY) || null);
  const [data, setData]             = useState(EMPTY_STATE);
  const [syncing, setSyncing]       = useState(false);
  const [online, setOnline]         = useState(true);
  const [lastSync, setLastSync]     = useState(null);
  const [toast, setToast]           = useState(null);
  const [screen, setScreen]         = useState("home");

  // Forms
  const [amount, setAmount]         = useState("");
  const [description, setDesc]      = useState("");
  const [category, setCategory]     = useState(null);
  const [step, setStep]             = useState(1);
  const [incAmt, setIncAmt]         = useState("");
  const [incDesc, setIncDesc]       = useState("");
  const [incStep, setIncStep]       = useState(1);

  const syncTimer = useRef(null);
  const pendingWrite = useRef(null);

  const showToast = (msg) => { setToast(msg); setTimeout(() => setToast(null), 2500); };

  // ── Init: create or load bin ──
  useEffect(() => {
    const init = async () => {
      setSyncing(true);
      try {
        let id = localStorage.getItem(BIN_ID_KEY);
        if (!id) {
          id = await createBin(EMPTY_STATE);
          localStorage.setItem(BIN_ID_KEY, id);
          setBinId(id);
        } else {
          setBinId(id);
        }
        const record = await readBin(id);
        setData(record || EMPTY_STATE);
        setLastSync(new Date());
        setOnline(true);
      } catch (e) {
        setOnline(false);
        // fallback to local
        try { setData(JSON.parse(localStorage.getItem("gf_data") || "null") || EMPTY_STATE); } catch {}
      }
      setSyncing(false);
    };
    init();
  }, []);

  // ── Poll every 8 seconds for real-time sync ──
  useEffect(() => {
    if (!binId) return;
    const poll = async () => {
      try {
        const record = await readBin(binId);
        if (record) {
          setData(record);
          setLastSync(new Date());
          setOnline(true);
        }
      } catch { setOnline(false); }
    };
    const interval = setInterval(poll, 8000);
    return () => clearInterval(interval);
  }, [binId]);

  // ── Debounced write to JSONBin ──
  const syncWrite = useCallback((newData) => {
    localStorage.setItem("gf_data", JSON.stringify(newData));
    if (!binId) return;
    if (syncTimer.current) clearTimeout(syncTimer.current);
    syncTimer.current = setTimeout(async () => {
      setSyncing(true);
      try {
        await writeBin(binId, newData);
        setLastSync(new Date());
        setOnline(true);
      } catch { setOnline(false); }
      setSyncing(false);
    }, 600);
  }, [binId]);

  const updateData = (fn) => {
    setData(prev => {
      const next = fn(prev);
      syncWrite(next);
      return next;
    });
  };

  // ── Helpers ──
  const expenses = data.expenses || [];
  const incomes  = data.incomes  || [];
  const shopping = data.shopping || [];

  const userExp   = (uid) => expenses.filter(e => e.user === uid);
  const userInc   = (uid) => incomes.filter(i => i.user === uid);
  const totInc    = (uid) => userInc(uid).reduce((s,i) => s+i.amount, 0);
  const totExp    = (uid) => userExp(uid).reduce((s,e) => s+e.amount, 0);
  const balance   = (uid) => totInc(uid) - totExp(uid);
  const weekExp   = (uid) => { const sw = startOfWeekStr(); return userExp(uid).filter(e=>e.date>=sw).reduce((s,e)=>s+e.amount,0); };
  const sharedBal = () => incomes.reduce((s,i)=>s+i.amount,0) - expenses.reduce((s,e)=>s+e.amount,0);
  const forecast  = (uid) => { const dow = new Date().getDay()||7; return (weekExp(uid)/dow)*(7-dow); };

  const saveExpense = () => {
    if (!amount || !category) return;
    const exp = { id: uid(), amount: parseFloat(amount), description, category, user: activeUser, date: todayStr() };
    updateData(d => ({
      ...d,
      expenses: [exp, ...(d.expenses||[])],
      shopping: (category==="mercaderia" && description.trim())
        ? [{ id: uid(), text: description.trim(), checked: false, from: "expense" }, ...(d.shopping||[])]
        : (d.shopping||[])
    }));
    setAmount(""); setDesc(""); setCategory(null); setStep(1);
    setScreen("home"); showToast("✓ Gasto registrado");
  };

  const saveIncome = () => {
    if (!incAmt) return;
    const inc = { id: uid(), amount: parseFloat(incAmt), description: incDesc||"Sueldo", user: activeUser, date: todayStr() };
    updateData(d => ({ ...d, incomes: [inc, ...(d.incomes||[])] }));
    setIncAmt(""); setIncDesc(""); setIncStep(1);
    setScreen("home"); showToast("✓ Ingreso registrado");
  };

  const delExpense  = (id) => updateData(d => ({ ...d, expenses: d.expenses.filter(e=>e.id!==id) }));
  const toggleShop  = (id) => updateData(d => ({ ...d, shopping: d.shopping.map(i=>i.id===id?{...i,checked:!i.checked}:i) }));
  const delShop     = (id) => updateData(d => ({ ...d, shopping: d.shopping.filter(i=>i.id!==id) }));
  const addShop     = (text) => updateData(d => ({ ...d, shopping: [{ id:uid(), text, checked:false, from:"manual" }, ...(d.shopping||[])] }));
  const clearChecked= () => updateData(d => ({ ...d, shopping: d.shopping.filter(i=>!i.checked) }));

  if (!activeUser) return <div style={S.root}><style>{CSS}</style><UserPicker onPick={setActiveUser} /></div>;

  const user = USERS.find(u => u.id === activeUser) || USERS[0];

  return (
    <div style={S.root}>
      <style>{CSS}</style>
      {toast && <div style={S.toast}>{toast}</div>}

      {/* Sync indicator */}
      <div style={{ position:"fixed", top:14, right:16, display:"flex", alignItems:"center", gap:5, zIndex:100 }}>
        {syncing && <div style={S.spinner} />}
        <div style={{ ...S.syncDot, background: online ? "#2D7D6F" : "#E0A555" }} title={online?"Sincronizado":"Sin conexión"} />
      </div>

      {/* ══ HOME ══ */}
      {screen === "home" && (
        <div style={S.screen}>
          <div style={S.header}>
            <div>
              <div style={S.headerLabel}>Gastos familiares</div>
              <div style={S.headerDate}>{new Date().toLocaleDateString("es-AR",{weekday:"long",day:"numeric",month:"long"})}</div>
            </div>
            <div style={S.userToggle}>
              {USERS.map(u => (
                <button key={u.id} onClick={() => { setActiveUser(u.id); localStorage.setItem("gf_user",u.id); }}
                  style={{ ...S.userBtn, ...(activeUser===u.id ? { ...S.userBtnActive, color:u.color }:{}) }}>
                  {u.avatar}
                </button>
              ))}
            </div>
          </div>

          {/* Balance card */}
          <div style={{ ...S.card, borderLeft:`4px solid ${user.color}`, margin:"0 24px 12px" }}>
            <div style={S.balTop}>
              <div>
                <div style={{ fontSize:15, fontWeight:700, color:user.color }}>{user.name}</div>
                <div style={{ fontSize:12, color:"#BBB", marginTop:2 }}>Saldo disponible</div>
              </div>
              <div style={{ fontSize:26, fontWeight:700, letterSpacing:"-1px", color:balance(activeUser)>=0?"#1A1A1A":"#E05555" }}>
                {fmt(balance(activeUser))}
              </div>
            </div>
            <div style={{ display:"flex", alignItems:"center" }}>
              <div style={S.balStat}><span style={S.balLbl}>↑ Ingresos</span><span style={{ fontSize:13, fontWeight:600, color:"#2D7D6F" }}>{fmt(totInc(activeUser))}</span></div>
              <div style={S.balDiv} />
              <div style={S.balStat}><span style={S.balLbl}>↓ Gastos</span><span style={{ fontSize:13, fontWeight:600, color:"#E05555" }}>{fmt(totExp(activeUser))}</span></div>
              <div style={S.balDiv} />
              <div style={S.balStat}><span style={S.balLbl}>📅 Semana</span><span style={{ fontSize:13, fontWeight:600, color:"#1A1A1A" }}>{fmt(weekExp(activeUser))}</span></div>
            </div>
          </div>

          {/* Shared */}
          <div style={{ ...S.darkCard, margin:"0 24px 12px" }}>
            <span style={{ fontSize:13, color:"rgba(255,255,255,0.6)", fontWeight:500 }}>💰 Fondo compartido</span>
            <span style={{ fontSize:18, fontWeight:700, letterSpacing:"-0.5px", color:sharedBal()>=0?"#5DCEA0":"#FF8080" }}>{fmt(sharedBal())}</span>
          </div>

          {/* Forecast */}
          <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:10, padding:"0 24px", marginBottom:16 }}>
            {USERS.map(u => (
              <div key={u.id} style={{ ...S.card, textAlign:"center", padding:"14px 16px" }}>
                <div style={{ width:28, height:28, borderRadius:10, border:`2px solid ${u.color}40`, display:"flex", alignItems:"center", justifyContent:"center", fontWeight:700, fontSize:13, margin:"0 auto 6px", color:u.color }}>{u.avatar}</div>
                <div style={{ fontSize:11, color:"#BBB", marginBottom:4 }}>Previsión semana</div>
                <div style={{ fontSize:15, fontWeight:700, letterSpacing:"-0.3px", color:u.color }}>{fmt(forecast(u.id))}</div>
              </div>
            ))}
          </div>

          {/* Actions */}
          <div style={{ padding:"0 24px", marginBottom:20, display:"flex", flexDirection:"column", gap:10 }}>
            <button className="btn-main" style={{ ...S.btnPrimary, background:user.color }}
              onClick={() => { setStep(1); setScreen("add"); }}>
              <span style={{fontSize:20}}>+</span> Registrar gasto
            </button>
            <div style={{ display:"flex", gap:10 }}>
              <button className="btn-sec" style={S.btnSec} onClick={() => { setIncStep(1); setScreen("income"); }}>↑ Ingreso</button>
              <button className="btn-sec" style={S.btnSec} onClick={() => setScreen("shopping")}>
                🛒 Lista
                {shopping.filter(s=>!s.checked).length > 0 && (
                  <span style={{ ...S.badge, background:user.color }}>{shopping.filter(s=>!s.checked).length}</span>
                )}
              </button>
              <button className="btn-sec" style={S.btnSec} onClick={() => setScreen("dashboard")}>▦ Ver</button>
            </div>
          </div>

          {/* Recent */}
          <div style={{ padding:"0 24px" }}>
            <div style={S.sectionTitle}>Últimos movimientos · {user.name}</div>
            {userExp(activeUser).length === 0 && <div style={S.empty}>Sin gastos registrados</div>}
            {userExp(activeUser).slice(0,7).map(e => {
              const cat = getCat(e.category);
              return (
                <div key={e.id} style={S.expRow}>
                  <div style={{ ...S.expIcon, background:cat.color+"20", color:cat.color }}>{cat.icon}</div>
                  <div style={{ flex:1, minWidth:0 }}>
                    <div style={S.expName}>{e.description || cat.label}</div>
                    <div style={S.expMeta}>{cat.label} · {e.date ? new Date(e.date+"T12:00:00").toLocaleDateString("es-AR",{day:"numeric",month:"short"}) : ""}</div>
                  </div>
                  <div style={{ fontSize:15, fontWeight:600, color:"#1A1A1A", flexShrink:0 }}>{fmt(e.amount)}</div>
                  <button style={S.delBtn} onClick={() => delExpense(e.id)}>×</button>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* ══ ADD EXPENSE ══ */}
      {screen === "add" && (
        <div style={S.screen}>
          <SubHeader title={`Nuevo gasto · ${user.name}`} onBack={() => { setStep(1); setScreen("home"); }} />
          <Steps current={step} total={3} color={user.color} />
          {step===1 && <div style={S.pane}><div style={S.stepQ}>¿Cuánto gastaste?</div><AmtDisplay value={amount} color={user.color} /><Numpad value={amount} onChange={setAmount} onConfirm={() => amount && setStep(2)} color={user.color} /></div>}
          {step===2 && (
            <div style={S.pane}>
              <div style={S.stepQ}>¿En qué categoría?</div>
              <div style={S.catGrid}>
                {CATEGORIES.map(c => (
                  <button key={c.id} className="cat-btn" style={{ ...S.catBtn, ...(category===c.id?{borderColor:c.color,background:c.color+"18"}:{}) }}
                    onClick={() => { setCategory(c.id); setStep(3); }}>
                    <span style={{fontSize:24}}>{c.icon}</span>
                    <span style={{fontSize:11,fontWeight:500,color:"#555"}}>{c.label}</span>
                  </button>
                ))}
              </div>
            </div>
          )}
          {step===3 && (
            <div style={S.pane}>
              <div style={S.stepQ}>Confirmá</div>
              <div style={{ ...S.card, marginBottom:24, textAlign:"center", padding:24 }}>
                <div style={{ fontSize:40, fontWeight:700, color:"#1A1A1A", letterSpacing:"-1px", marginBottom:8 }}>{fmt(parseFloat(amount))}</div>
                <div style={{ fontSize:16, fontWeight:500, color:getCat(category).color, marginBottom:20 }}>{getCat(category).icon} {getCat(category).label}</div>
                <input style={S.descInput} placeholder="Descripción (opcional)" value={description} onChange={e=>setDesc(e.target.value)} maxLength={50} />
                {category==="mercaderia" && description && <div style={{marginTop:12,fontSize:12,color:"#2D7D6F",fontWeight:500}}>🛒 Se agregará a lista de compras</div>}
              </div>
              <div style={{display:"flex",gap:10}}>
                <button style={S.btnOutline} onClick={() => setStep(2)}>← Editar</button>
                <button className="btn-main" style={{ ...S.btnPrimary, flex:1, background:user.color }} onClick={saveExpense}>Guardar</button>
              </div>
            </div>
          )}
        </div>
      )}

      {/* ══ INCOME ══ */}
      {screen === "income" && (
        <div style={S.screen}>
          <SubHeader title={`Ingreso · ${user.name}`} onBack={() => { setIncStep(1); setScreen("home"); }} />
          <Steps current={incStep} total={2} color="#2D7D6F" />
          {incStep===1 && <div style={S.pane}><div style={S.stepQ}>¿Cuánto ingresaste?</div><AmtDisplay value={incAmt} color="#2D7D6F" /><Numpad value={incAmt} onChange={setIncAmt} onConfirm={() => incAmt && setIncStep(2)} color="#2D7D6F" /></div>}
          {incStep===2 && (
            <div style={S.pane}>
              <div style={S.stepQ}>Confirmá el ingreso</div>
              <div style={{ ...S.card, marginBottom:24, textAlign:"center", padding:24, borderTop:"3px solid #2D7D6F" }}>
                <div style={{ fontSize:40, fontWeight:700, color:"#2D7D6F", letterSpacing:"-1px", marginBottom:8 }}>{fmt(parseFloat(incAmt))}</div>
                <div style={{ fontSize:14, color:"#888", marginBottom:20 }}>↑ Ingreso para {user.name}</div>
                <input style={S.descInput} placeholder="Descripción (ej: Sueldo enero)" value={incDesc} onChange={e=>setIncDesc(e.target.value)} maxLength={50} />
              </div>
              <div style={{display:"flex",gap:10}}>
                <button style={S.btnOutline} onClick={() => setIncStep(1)}>← Editar</button>
                <button className="btn-main" style={{ ...S.btnPrimary, flex:1, background:"#2D7D6F" }} onClick={saveIncome}>Guardar ingreso</button>
              </div>
            </div>
          )}
        </div>
      )}

      {/* ══ SHOPPING ══ */}
      {screen === "shopping" && (
        <div style={S.screen}>
          <SubHeader title="Lista de compras" onBack={() => setScreen("home")}
            right={<button style={{fontSize:12,background:"none",border:"none",cursor:"pointer",color:"#BBB"}} onClick={clearChecked}>Limpiar ✓</button>} />
          <div style={{padding:"0 24px",marginBottom:16}}><ShoppingInput onAdd={addShop} /></div>
          <div style={{padding:"0 24px"}}>
            {shopping.length===0 && <div style={S.empty}>La lista está vacía</div>}
            {shopping.map(item => (
              <div key={item.id} style={{ ...S.expRow, ...(item.checked?{opacity:0.4}:{}) }}>
                <button style={{ ...S.checkBox, ...(item.checked?{background:"#2D7D6F",borderColor:"#2D7D6F"}:{}) }} onClick={() => toggleShop(item.id)}>
                  {item.checked && "✓"}
                </button>
                <span style={{flex:1,fontSize:15,color:"#1A1A1A",...(item.checked?{textDecoration:"line-through"}:{})}}>{item.text}</span>
                {item.from==="expense" && <span style={S.autoTag}>auto</span>}
                <button style={S.delBtn} onClick={() => delShop(item.id)}>×</button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ══ DASHBOARD ══ */}
      {screen === "dashboard" && (
        <div style={S.screen}>
          <SubHeader title="Resumen comparativo" onBack={() => setScreen("home")} />
          <div style={{padding:"0 24px",marginBottom:20}}>
            <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:12}}>
              {USERS.map(u => (
                <div key={u.id} style={{ ...S.card, borderTop:`3px solid ${u.color}` }}>
                  <div style={{fontSize:22,fontWeight:700,color:u.color,marginBottom:2}}>{u.avatar}</div>
                  <div style={{fontSize:13,fontWeight:600,color:"#1A1A1A",marginBottom:10}}>{u.name}</div>
                  {[["Ingresos","#2D7D6F",totInc(u.id)],["Gastos","#E05555",totExp(u.id)]].map(([l,c,v])=>(
                    <div key={l} style={{display:"flex",justifyContent:"space-between",marginBottom:6}}>
                      <span style={{fontSize:12,color:"#BBB"}}>{l}</span>
                      <span style={{fontSize:12,fontWeight:600,color:c}}>{fmt(v)}</span>
                    </div>
                  ))}
                  <div style={{display:"flex",justifyContent:"space-between",marginTop:6,paddingTop:6,borderTop:"1px solid #F0F0ED"}}>
                    <span style={{fontSize:12,color:"#BBB"}}>Saldo</span>
                    <span style={{fontSize:13,fontWeight:700,color:balance(u.id)>=0?"#2D7D6F":"#E05555"}}>{fmt(balance(u.id))}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div style={{padding:"0 24px"}}>
            <div style={S.sectionTitle}>Gastos por categoría</div>
            {CATEGORIES.map(cat => {
              const nT = userExp("N").filter(e=>e.category===cat.id).reduce((s,e)=>s+e.amount,0);
              const fT = userExp("F").filter(e=>e.category===cat.id).reduce((s,e)=>s+e.amount,0);
              if (nT+fT===0) return null;
              const max = Math.max(...CATEGORIES.map(c=>expenses.filter(e=>e.category===c.id).reduce((s,e)=>s+e.amount,0)),1);
              return (
                <div key={cat.id} style={{marginBottom:16}}>
                  <div style={{display:"flex",justifyContent:"space-between",marginBottom:5}}>
                    <span style={{fontSize:13,fontWeight:500}}>{cat.icon} {cat.label}</span>
                    <span style={{fontSize:12,color:"#888"}}>{fmt(nT+fT)}</span>
                  </div>
                  <div style={{display:"flex",gap:3}}>
                    {[nT,fT].map((v,i)=>(
                      <div key={i} style={{flex:1,height:6,background:"#EBEBEB",borderRadius:3,overflow:"hidden"}}>
                        <div style={{height:"100%",width:`${(v/max)*100}%`,background:USERS[i].color,borderRadius:3}} />
                      </div>
                    ))}
                  </div>
                  <div style={{display:"flex",justifyContent:"space-between",marginTop:3}}>
                    <span style={{fontSize:10,color:USERS[0].color}}>N: {fmt(nT)}</span>
                    <span style={{fontSize:10,color:USERS[1].color}}>F: {fmt(fT)}</span>
                  </div>
                </div>
              );
            })}
            {expenses.length===0 && <div style={S.empty}>Sin datos aún</div>}
          </div>

          <div style={{padding:"16px 24px"}}>
            <button style={S.btnDanger} onClick={() => {
              if (window.confirm("¿Borrar todos los datos?")) updateData(() => EMPTY_STATE);
            }}>Borrar todos los datos</button>
            <button style={{...S.btnDanger,marginTop:10,borderColor:"#EBEBEB",color:"#BBB"}}
              onClick={() => { localStorage.removeItem("gf_user"); setActiveUser(null); }}>
              Cambiar usuario
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

// ── Sub-components ──
function SubHeader({ title, onBack, right }) {
  return (
    <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", padding:"52px 24px 20px" }}>
      <button style={S.backBtn} onClick={onBack}>←</button>
      <div style={{ fontSize:16, fontWeight:600, color:"#1A1A1A" }}>{title}</div>
      {right || <div style={{width:36}} />}
    </div>
  );
}
function Steps({ current, total, color }) {
  return (
    <div style={{ display:"flex", gap:6, justifyContent:"center", marginBottom:28 }}>
      {Array.from({length:total},(_,i)=>(
        <div key={i} style={{ width: current>i?20:6, height:6, borderRadius:3, background:current>i?color:"#ECECEC", transition:"all 0.2s" }} />
      ))}
    </div>
  );
}
function AmtDisplay({ value, color }) {
  return (
    <div style={{ textAlign:"center", marginBottom:32, display:"flex", alignItems:"baseline", justifyContent:"center", gap:4 }}>
      <span style={{ fontSize:28, fontWeight:300, color:"#BBB" }}>$</span>
      <span style={{ fontSize:56, fontWeight:700, color: value ? color : "#DDD", letterSpacing:"-2px", lineHeight:1 }}>{value||"0"}</span>
    </div>
  );
}
function Numpad({ value, onChange, onConfirm, color }) {
  return (
    <div style={{ display:"grid", gridTemplateColumns:"repeat(3, 1fr)", gap:10 }}>
      {["1","2","3","4","5","6","7","8","9","⌫","0","✓"].map(k => (
        <button key={k} className="numkey"
          style={{ ...S.numKey, ...(k==="✓"?{background:color,color:"#fff"}:k==="⌫"?{background:"#F0F0ED",color:"#888"}:{}) }}
          onClick={() => {
            if (k==="⌫") onChange(v=>v.slice(0,-1));
            else if (k==="✓") onConfirm();
            else onChange(v=>v.length<9?v+k:v);
          }}>{k}</button>
      ))}
    </div>
  );
}
function ShoppingInput({ onAdd }) {
  const [val, setVal] = useState("");
  const submit = () => { if(val.trim()){onAdd(val.trim());setVal("");} };
  return (
    <div style={{display:"flex",gap:8}}>
      <input style={{flex:1,border:"none",background:"#fff",borderRadius:12,padding:"14px 16px",fontSize:15,outline:"none",boxShadow:"0 1px 6px rgba(0,0,0,0.06)"}}
        placeholder="Agregar ítem..." value={val} onChange={e=>setVal(e.target.value)} onKeyDown={e=>e.key==="Enter"&&submit()} />
      <button style={{width:48,height:48,flexShrink:0,background:"#2D7D6F",color:"#fff",border:"none",borderRadius:12,fontSize:22,cursor:"pointer"}} onClick={submit}>+</button>
    </div>
  );
}

// ── Styles ──
const S = {
  root: { fontFamily:"'DM Sans','Helvetica Neue',sans-serif", background:"#F7F6F3", minHeight:"100vh", maxWidth:420, margin:"0 auto", position:"relative" },
  screen: { minHeight:"100vh", paddingBottom:32, display:"flex", flexDirection:"column" },
  toast: { position:"fixed", top:20, left:"50%", transform:"translateX(-50%)", background:"#1A1A1A", color:"#fff", padding:"10px 20px", borderRadius:30, fontSize:13, fontWeight:500, zIndex:1000, boxShadow:"0 4px 20px rgba(0,0,0,0.2)", animation:"fadeInDown 0.2s ease", whiteSpace:"nowrap" },
  syncDot: { width:8, height:8, borderRadius:4, transition:"background 0.4s" },
  spinner: { width:12, height:12, borderRadius:"50%", border:"2px solid #DDD", borderTopColor:"#2D7D6F", animation:"spin 0.8s linear infinite" },
  header: { padding:"52px 24px 16px", display:"flex", justifyContent:"space-between", alignItems:"flex-start" },
  headerLabel: { fontSize:22, fontWeight:700, color:"#1A1A1A", letterSpacing:"-0.5px" },
  headerDate: { fontSize:13, color:"#888", marginTop:3, textTransform:"capitalize" },
  userToggle: { display:"flex", gap:6, background:"#ECECEC", borderRadius:20, padding:4 },
  userBtn: { width:32, height:32, borderRadius:16, border:"none", background:"transparent", cursor:"pointer", fontSize:13, fontWeight:700, color:"#888", transition:"all 0.15s" },
  userBtnActive: { background:"#fff", boxShadow:"0 1px 4px rgba(0,0,0,0.12)" },
  card: { background:"#fff", borderRadius:16, padding:"18px 20px", boxShadow:"0 1px 8px rgba(0,0,0,0.06)" },
  darkCard: { background:"#1A1A1A", borderRadius:14, padding:"14px 18px", display:"flex", justifyContent:"space-between", alignItems:"center" },
  balTop: { display:"flex", justifyContent:"space-between", alignItems:"flex-start", marginBottom:14 },
  balStat: { flex:1, display:"flex", flexDirection:"column", gap:3 },
  balLbl: { fontSize:11, color:"#BBB" },
  balDiv: { width:1, height:28, background:"#F0F0ED", margin:"0 8px" },
  btnPrimary: { border:"none", borderRadius:14, padding:"16px 24px", fontSize:15, fontWeight:600, cursor:"pointer", display:"flex", alignItems:"center", justifyContent:"center", gap:8, color:"#fff", letterSpacing:"-0.2px", width:"100%" },
  btnSec: { flex:1, background:"#fff", color:"#1A1A1A", border:"none", borderRadius:14, padding:"13px 8px", fontSize:13, fontWeight:500, cursor:"pointer", display:"flex", alignItems:"center", justifyContent:"center", gap:5, boxShadow:"0 1px 6px rgba(0,0,0,0.06)", position:"relative" },
  badge: { color:"#fff", borderRadius:10, fontSize:10, fontWeight:700, padding:"2px 6px" },
  sectionTitle: { fontSize:12, fontWeight:600, color:"#BBB", letterSpacing:"0.8px", textTransform:"uppercase", marginBottom:12 },
  expRow: { display:"flex", alignItems:"center", gap:12, padding:"11px 0", borderBottom:"1px solid #F0F0ED" },
  expIcon: { width:40, height:40, borderRadius:12, display:"flex", alignItems:"center", justifyContent:"center", fontSize:18, flexShrink:0 },
  expName: { fontSize:14, fontWeight:500, color:"#1A1A1A", whiteSpace:"nowrap", overflow:"hidden", textOverflow:"ellipsis" },
  expMeta: { fontSize:12, color:"#BBB", marginTop:2 },
  delBtn: { background:"none", border:"none", cursor:"pointer", fontSize:18, color:"#DDD", padding:"0 2px", flexShrink:0 },
  empty: { fontSize:14, color:"#CCC", textAlign:"center", padding:"24px 0" },
  backBtn: { width:36, height:36, borderRadius:10, border:"none", background:"#ECECEC", cursor:"pointer", fontSize:18 },
  pane: { padding:"0 24px", flex:1 },
  stepQ: { fontSize:20, fontWeight:700, color:"#1A1A1A", marginBottom:28, letterSpacing:"-0.3px" },
  numKey: { background:"#fff", border:"none", borderRadius:14, padding:"18px 0", fontSize:22, fontWeight:500, cursor:"pointer", color:"#1A1A1A", boxShadow:"0 1px 4px rgba(0,0,0,0.06)" },
  catGrid: { display:"grid", gridTemplateColumns:"repeat(3, 1fr)", gap:10 },
  catBtn: { background:"#fff", border:"2px solid transparent", borderRadius:14, padding:"16px 8px", cursor:"pointer", display:"flex", flexDirection:"column", alignItems:"center", gap:6, boxShadow:"0 1px 4px rgba(0,0,0,0.06)" },
  descInput: { width:"100%", border:"none", borderBottom:"1.5px solid #EBEBEB", padding:"10px 0", fontSize:15, outline:"none", textAlign:"center", background:"transparent", color:"#1A1A1A", boxSizing:"border-box" },
  btnOutline: { background:"#fff", border:"1.5px solid #EBEBEB", borderRadius:14, padding:"16px 20px", fontSize:14, fontWeight:500, cursor:"pointer", color:"#555" },
  checkBox: { width:24, height:24, borderRadius:8, border:"2px solid #DDD", background:"none", cursor:"pointer", display:"flex", alignItems:"center", justifyContent:"center", fontSize:12, fontWeight:700, color:"#fff", flexShrink:0 },
  autoTag: { fontSize:10, background:"#2D7D6F18", color:"#2D7D6F", padding:"2px 7px", borderRadius:6, fontWeight:600 },
  btnDanger: { width:"100%", background:"none", border:"1.5px solid #FFDDDD", color:"#E05555", borderRadius:14, padding:14, fontSize:14, cursor:"pointer" },
};

const CSS = `
  @import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@300;400;500;600;700&display=swap');
  * { -webkit-tap-highlight-color: transparent; box-sizing: border-box; }
  body { margin: 0; background: #F7F6F3; }
  .btn-main:active { transform: scale(0.97); }
  .btn-sec:active { transform: scale(0.97); }
  .numkey:active { transform: scale(0.93); }
  .cat-btn:hover { transform: translateY(-1px); }
  @keyframes fadeInDown { from{opacity:0;transform:translate(-50%,-8px)} to{opacity:1;transform:translate(-50%,0)} }
  @keyframes spin { to { transform: rotate(360deg); } }
`;
